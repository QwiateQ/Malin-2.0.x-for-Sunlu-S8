# BIQU B1 BLTouch Firmware

This firmware retains the use of homing with a Z limit switch. If you want to home with a BLTouch, enable (uncomment) `USE_PROBE_FOR_Z_HOMING` and `Z_SAFE_HOMING` and remove the adjustable Z limit switch bracket.
